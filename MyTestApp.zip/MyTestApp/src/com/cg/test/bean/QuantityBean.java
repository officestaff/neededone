package com.cg.test.bean;

import javax.validation.constraints.Min;

import org.hibernate.validator.constraints.NotEmpty;

public class QuantityBean {
	@Min(value=1,message="Quantity should be greater than ZERO")
	private int quantity;
	@NotEmpty(message="Please select one of the actions")
	private String action;
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getAction() {
		return action;
	}
	public void setAction(String action) {
		this.action = action;
	}
	
}
