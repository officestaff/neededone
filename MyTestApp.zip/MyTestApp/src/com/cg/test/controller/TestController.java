package com.cg.test.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.test.bean.OrderBean;
import com.cg.test.bean.QuantityBean;
import com.cg.test.bean.StockBean;
import com.cg.test.exception.StockException;
import com.cg.test.service.TestService;

@Controller
public class TestController {
	@Autowired
	TestService service;
	@RequestMapping("/")
	public ModelAndView showIndex() {
		ModelAndView mv=null;
		try {
			List<StockBean> stocks=service.getAllStocks();
			mv=new ModelAndView("stocks","stocks",stocks);
		} catch (StockException e) {
			mv=new ModelAndView("error","exception","An Error Occured "+e.getMessage());
			
		}
		return mv;
		
	}
	@RequestMapping("/showStock")
	public ModelAndView showStock(@RequestParam("stockName") 
			String stockName) {
		ModelAndView mv=null;
		try {
			StockBean stock=service.getStockByName(stockName);
			mv=new ModelAndView("showStock","stock",stock);
			String [] actions=new String[] {"Buy","Sell"};
			mv.addObject("actions",actions);
			mv.addObject("quantity",new QuantityBean());
			
			
		} catch (StockException e) {
			mv=new ModelAndView("error","exception","An Error Occured "+e.getMessage());
		}
		return mv;
	}
	@RequestMapping("/updateStock")
	public ModelAndView updateStock(@Valid @ModelAttribute("quantity")
		QuantityBean quantity,BindingResult result,@ModelAttribute("stock") StockBean stock
		) {
		if(result.hasErrors()) {
			String [] actions=new String[] {"Buy","Sell"};
			
			return new ModelAndView("showStock","actions",actions);
		}
		String action=quantity.getAction();
		ModelAndView mv=null;
		double comm=0;
		double orderAmt=stock.getQuote()*quantity.getQuantity();
		if(action.equals("Buy")) {
			comm=orderAmt*.5/100;
		}
		else if(action.equals("Sell")) {
			comm=orderAmt*1/100;
		}
		OrderBean bean=new OrderBean();
		bean.setStock(stock.getStock());
		bean.setQuote(stock.getQuote());
		bean.setCommission(comm);
		bean.setOrderAmount(orderAmt);
		try {
			bean=service.updateStock(bean);
			mv=new ModelAndView("summary","order",bean);
		} catch (StockException e) {
			mv=new ModelAndView("error","exception","An Error Occured "+e.getMessage());
		}
		
		return mv;
	}
	
}
