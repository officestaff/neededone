package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.exception.TraineeException;

@Repository
@Transactional
public class TraineeDaoImpl implements TraineeDao {
	
	@PersistenceContext
	EntityManager entityManager;
	
	
	@Override
	public void addTrainee(TraineeBean bean) throws TraineeException {

		
			try {
				entityManager.persist(bean);
				
			} 
			catch (Exception e) {
				throw new TraineeException("unable to persist in Dao Layer"
						+ e.getMessage());
			}

			
		
	}

	@Override
	public List<TraineeBean> getAllTrainees() throws TraineeException {
		
		List<TraineeBean> trainees = null;
		try
		{
		String jpql = "SELECT trainee FROM TraineeBean trainee";
		TypedQuery<TraineeBean> query = entityManager.createQuery(jpql, TraineeBean.class);
		trainees = query.getResultList();
		
		}
	catch(Exception ex)
		{
		throw new TraineeException(ex.getMessage());
		}
	
	return trainees;
}

	@Override
	public TraineeBean getTraineeById(int traineeId) throws TraineeException {
		
		TraineeBean bean = entityManager.find(TraineeBean.class, traineeId);

		return bean;
	
		
	}

	@Override

	public TraineeBean deleteTraineeById(int traineeId) throws TraineeException {
		
		TraineeBean bean = entityManager.find(TraineeBean.class, traineeId);
		
			entityManager.remove(bean);
		
		
		return bean;
	}


	@Override
	public TraineeBean modifyTrainee(int traineeId, String traineeName,
			String traineeDomain, String traineeLocation)
			throws TraineeException {
		
		TraineeBean bean;
		try {
			bean = entityManager.find(TraineeBean.class, traineeId);
			bean.setTraineeName(traineeName);
			bean.setTraineeDomain(traineeDomain);
			bean.setTraineeLocation(traineeLocation);
			entityManager.merge(bean);
		} catch (Exception e) {
			throw new TraineeException("Not updated in dao layer"
					+ e.getMessage());
		}

		return bean;
		
	}
		
	}

	

