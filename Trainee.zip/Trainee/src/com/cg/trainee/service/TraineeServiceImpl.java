package com.cg.trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.bean.TraineeBean;
import com.cg.trainee.dao.TraineeDao;
import com.cg.trainee.exception.TraineeException;

@Service
public class TraineeServiceImpl implements TraineeService {
	@Autowired
	TraineeDao traineeDao;
	
	@Override
	public void addTrainee(TraineeBean bean) throws TraineeException {
		
		 traineeDao.addTrainee(bean);
		
	}

	@Override
	public List<TraineeBean> getAllTrainees() throws TraineeException {
		
		return traineeDao.getAllTrainees();
	}

	@Override
	public TraineeBean getTraineeById(int traineeId) throws TraineeException {
		
		return traineeDao.getTraineeById(traineeId);
	}

	@Override
	public TraineeBean deleteTraineeById(int traineeId) throws TraineeException {
		
		return traineeDao.deleteTraineeById(traineeId);
	}


	@Override
	public TraineeBean modifyTrainee(int traineeId, String traineeName,
			String traineeDomain, String traineeLocation)
			throws TraineeException {
		
		return traineeDao.modifyTrainee(traineeId, traineeName, traineeDomain, traineeLocation);
	}

}
